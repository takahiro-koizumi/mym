<?php
/**
* Template footer for LP
* @package WordPress
* @subpackage Emanon_Pro
* @since Emanon Pro 1.9.9
*/
?>

<?php emanon_cta_popup(); ?>
<!--footer-->
<footer class="footer">
	<?php emanon_cta_popup_modal_window(); ?>
</footer>
<!--end footer-->
<?php wp_footer(); ?>
</body>
</html>
<?php emanon_html_compress_end(); ?>