<?php
/**
 * Floating page top［PC］
 *
 * @since 1.0.0
 * @package Emanon Premium
 */
?>

<div id="js-smooth-scroll" class="page-top-floating" aria-label="トップへ戻るボタン">
<i class="icon-chevron-up" aria-hidden="true"></i>
</div><!--/.page-top-floating"-->
