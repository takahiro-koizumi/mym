<?php
/**
 * The template for displaying request
 *
 * @since 1.0.0
 * @package Emanon Premium
 */

get_header();
?>

<?php
get_template_part( 'template-parts/layout/post/post-request-layout' );
get_footer();