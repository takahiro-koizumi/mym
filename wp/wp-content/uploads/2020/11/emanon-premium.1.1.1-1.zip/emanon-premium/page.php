<?php
/**
 * The template for displaying pages
 *
 * @since 1.0.0
 * @package Emanon Premium
 */

get_header();
?>

<?php
get_template_part( 'template-parts/layout/page/page-layout' );
get_footer();