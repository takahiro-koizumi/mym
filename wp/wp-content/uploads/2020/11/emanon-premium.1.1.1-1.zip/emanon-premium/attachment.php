<?php
/**
 * The template for displaying attachment
 *
 * @since 1.0.0
 * @package Emanon Premium
 */

get_header();
?>

<?php
get_template_part( 'template-parts/layout/post/post-attachment-layout' );
get_footer();