<?php
/**
 * The template for displaying news
 *
 * @since 1.0.0
 * @package Emanon Premium
 */

get_header();
?>

<?php
get_template_part( 'template-parts/layout/post/post-news-layout' );
get_footer();