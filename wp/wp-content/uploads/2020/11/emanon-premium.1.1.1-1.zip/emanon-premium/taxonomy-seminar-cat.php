<?php
/**
 * The template for displaying taxonomy seminar
 *
 * @since 1.0.0
 * @package Emanon Premium
 */

get_header();
?>

<?php
get_template_part( 'template-parts/layout/taxonomy-term/seminar-cat-layout' );
get_footer();