(function ($) {

$(function () {
	$(".article-body p a[target='_blank']").append('<i class="icon-external-link"></i>');
});

})(jQuery);