<?php
/**
 * The template for displaying archive seminar
 *
 * @since 1.0.0
 * @package Emanon Premium
 */

get_header();
?>

<?php
get_template_part( 'template-parts/layout/archive/archive-seminar-layout' );
get_footer();