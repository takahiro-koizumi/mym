<?php
/**
 * The template for displaying taxonomy news
 *
 * @since 1.0.0
 * @package Emanon Premium
 */

get_header();
?>

<?php
get_template_part( 'template-parts/layout/taxonomy-term/news-cat-layout' );
get_footer();