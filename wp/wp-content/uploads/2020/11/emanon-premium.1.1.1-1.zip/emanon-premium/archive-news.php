<?php
/**
 * The template for displaying archive news
 *
 * @since 1.0.0
 * @package Emanon Premium
 */

get_header();
?>

<?php
get_template_part( 'template-parts/layout/archive/archive-news-layout' );
get_footer();