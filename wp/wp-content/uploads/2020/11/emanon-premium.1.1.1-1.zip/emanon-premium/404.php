<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @since 1.0.0
 * @package Emanon Premium
 */

get_header();
?>

<?php
get_template_part( 'template-parts/layout/404/404-layout' );
get_footer();
