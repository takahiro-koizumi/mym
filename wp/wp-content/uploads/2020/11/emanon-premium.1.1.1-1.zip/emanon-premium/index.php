<?php
/**
 * The template for displaying index pages
 *
 * @since 1.0.0
 * @package Emanon Premium
 */

get_header();
?>

<?php
get_template_part( 'template-parts/layout/archive/archive', 'layout' );
get_footer();